
import sys,os.path

prefix = sys.argv[1]

file_genes = open(prefix+".genes.txt","r").readlines()

genes = {}
for line in file_genes:
    if len(line.split()) > 2:
        genes[line.split()[1]] = 0

file_adjacencies = open(prefix+".adjacencies.txt","r").readlines()

for line in file_adjacencies:
    words = line.strip().split()
    if words[1].find("@")<0:
        genes[words[1]] = genes[words[1]] + float(words[6])
        genes[words[2]] = genes[words[2]] + float(words[6])

nbconf = 0
nb2 = 0
for g in genes.keys():
    #print g,genes[g]
    if genes[g] > 2:
        nbconf = nbconf + 1
    if genes[g] > 1.6 and genes[g] < 2.4:
        nb2 = nb2 + 1
        
nb_break = 0
max_sample = 1
if os.path.isfile(prefix+".adjacencyTrees.newick"):
    max_sample = 0
    file_adjacencyTrees = open(prefix+".adjacencyTrees.newick").readlines()
    for line in file_adjacencyTrees:
        if line[0] == ">":
            nb_break = nb_break + int(line.split()[9])
            #print int(line.split()[9]),nb_break
            if int(line.split()[3]) > max_sample:
                max_sample = int(line.split()[3])


print ">2, ~2, nb_breaks:",float(nbconf)/len(genes.keys()),float(nb2)/len(genes.keys()),float(nb_break)/max_sample