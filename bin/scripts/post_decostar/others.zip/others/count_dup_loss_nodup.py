import sys

file_reconciled_trees = open(sys.argv[1],"r").readlines()

nb_nodup = 0
nb_dup = 0
nb_losses = 0
for line in file_reconciled_trees:
    if line[0] != ">":
        dup = line.count("Dup")
        if dup == 0:
            nb_nodup = nb_nodup + 1
        else:
            nb_dup = nb_dup + dup
        nb_losses = nb_losses + line.count("Loss")

print "dup",nb_dup,"loss",nb_losses,"nodup_tree",nb_nodup