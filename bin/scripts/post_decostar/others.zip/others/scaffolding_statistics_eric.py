

XtopoGENE="./results/decostar/Xtopo+scaff/DeCoSTAR_Anopheles_Xtopo+scaff_Boltz_0.1.genes.txt"
GENE="data/GFF_to_GENE_files/with_filter/ALL_species_GENE_file_with_GF"
Xtopo_without_scaff="./results/decostar/Xtopo-scaff/DeCoSTAR_Anopheles_Xtopo-scaff_Boltz_0.1_0.1_M1_scaffolds"
Xtopo_with_scaff="./results/decostar/Xtopo+scaff/DeCoSTAR_Anopheles_Xtopo+scaff_Boltz_0.1_0.1_M1_scaffolds"

# read all genes
file_genes = open(XtopoGENE,"r").readlines()
genes = {}
for line in file_genes:
    words = line.split()
    species = words[0]
    gene = words[1]
    if gene.find("@") >= 0:
        genes[gene] = ""
    else:
        genes[species+"@"+gene] = ""
    
# initial scaffolding
init_scaffolds = {}
file_scaff_init = open(GENE,"r").readlines()
for line in file_scaff_init:
    if line[0] != "#":
        words = line.split()
        species = words[0]
        scaffold = words[1]
        gene = words[3]
        if genes.has_key(species+"@"+gene):
            if not init_scaffolds.has_key(species):
                init_scaffolds[species] = []
            if not scaffold in init_scaffolds[species]:
                init_scaffolds[species].append(scaffold)

for s in init_scaffolds.keys():
    print s,len(init_scaffolds[s])

file_without_scaffolding = open(Xtopo_without_scaff,"r").readlines()
file_with_scaffolding = open(Xtopo_with_scaff,"r").readlines()

#expe = {"S":{},"NS":{}}
#for line in file_with_scaffolding:
    #if line[0] != "#":
        #words = line.split()
        #species = words[0]
        #scaffold = words[1]
        #gene = words[2]
        #if not expe["S"].has_key(species):
            #expe["S"][species] = []
        #if not scaffold in expe["S"][species]:
            #expe["S"][species].append(scaffold)
        #genes[species+"@"+gene] = genes[species+"@"+gene] + "S"
        
#for line in file_without_scaffolding:
    #if line[0] != "#":
        #words = line.split()
        #species = words[0]
        #scaffold = words[1]
        #gene = words[2]
        #if not expe["NS"].has_key(species):
            #expe["NS"][species] = []
        #if not scaffold in expe["NS"][species]:
            #expe["NS"][species].append(scaffold)
        #genes[species+"@"+gene] = genes[species+"@"+gene] + "N"

#for s in expe["S"].keys():
    #expe["S"][s] = len(expe["S"][s])
    #expe["NS"][s] = len(expe["NS"][s])

    