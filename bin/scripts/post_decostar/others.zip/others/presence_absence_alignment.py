import sys,script_tree,string

species_tree = script_tree.readTree(open("data/Anopheles_species_tree_X_topology.nwk","r").readline())

all_species = []
leaves = script_tree.getLeavesNames(species_tree)
for l in leaves:
    all_species.append(l.split("@")[0])

sequences = {}
for s in all_species:
    #print s
    sequences[s] = []

gene_families = open("data/GENE_TREES/trees_DeCoSTAR_Xtopo.nwk","r").readlines()
for line in gene_families:
    #print line
    tree = script_tree.readTree(line)
    leaves = script_tree.getLeavesNames(tree)
    present_species = []
    good_family = True
    for l in leaves:
        if l.find("@") >= 0:
            species = l.split("@")[0]
            if species in present_species:
                good_family = False
                #print "dup species",species
            else:
                present_species.append(species)
    if good_family:
        for p in all_species:
            if p in present_species:
                sequences[p].append("1")
            else:
                sequences[p].append("0")

for s in all_species:
    print ">"+s
    #,len(sequences[s])
    print string.join(sequences[s],"")
            