
import sys

prefix = sys.argv[1]

file_gene = open(prefix+".genes.txt","r").readlines()
file_scaffold = open(prefix+"_0.1_M1_scaffolds","r").readlines()

genes = {}
for line in file_gene:
    words = line.strip().split()
    genes[words[1]] = [words[0]]

for line in file_scaffold:
    #print line
    if line[0] != "#":
        #print line
        words = line.strip().split()
        name = words[2]
        species = words[0]
        scaffold = words[1]
        genes[name].append(scaffold)

scaff = {}
number = 1
for g in genes.keys():
    species = genes[g][0]
    if not scaff.has_key(species):
        scaff[species] = {}
    if len(genes[g]) == 1:
        scaffold_name = "ADDITIONAL_"+str(number)
        genes[g].append(scaffold_name)
        number = number + 1
    else:
        scaffold_name = genes[g][1]
    if not scaff[species].has_key(scaffold_name):
        scaff[species][scaffold_name] = 0
    scaff[species][scaffold_name] = scaff[species][scaffold_name] + 1

total = 0.0
for s in scaff.keys():
    print s,len(scaff[s])
    total = total + len(scaff[s])

print "mean scaffold number",total/len(scaff.keys())



