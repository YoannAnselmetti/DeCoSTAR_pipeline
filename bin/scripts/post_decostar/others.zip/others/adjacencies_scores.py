# Cedric Chauve, March 2017
# Generates the distribution of scores of two sets of adjacencies (discarded and kept)

# Usage
# python adjacencies_scores.py <discarded adjacencies file> <kept adjacencies file> <output file name> <comment>

import sys;
import numpy as np;

# --------------- Reading adjacencies ----------------------------------------------
def adj_species(adj):
    return(adj[0])
def adj_gene1(adj):
    return(adj[1])
def adj_gene2(adj):
    return(adj[2])
def adj_or1(adj):
    return(adj[3])
def adj_or2(adj):
    return(adj[4])
def adj_prior(adj):
    return(adj[5])
def adj_posterior(adj):
    return(adj[6])
def adj_filtering(adj):
    return(adj[7])

def read_adj(adj_line):
    # 1 Anopheles_arabiensis@AARA000001 Anopheles_arabiensis@AARA002493 + + 0.336781 0.0      1
    adj1 = adj_line.rstrip().split()
    return((adj1[0],adj1[1],adj1[2],adj1[3],adj1[4],float(adj1[5]),float(adj1[6]),adj1[7]))

def read_adj_stream(stream):
    species_list = []
    adjacencies = {}
    for s in stream:
        if s[0]!='#':
            adj=read_adj(s)
            species=adj_species(adj)
            if species not in species_list:
                species_list.append(species)
                adjacencies[species]=[]
            adjacencies[species].append(adj)
    return((species_list,adjacencies))


# --------------- Main ----------------------------------------------

disc_adj_file = sys.argv[1]
disc_adj_stream = open(disc_adj_file,'r').readlines()
(disc_species_list,disc_adjacencies) = read_adj_stream(disc_adj_stream)
    
kept_adj_file = sys.argv[2]
kept_adj_stream = open(kept_adj_file,'r').readlines()
(kept_species_list,kept_adjacencies) = read_adj_stream(kept_adj_stream)

output_file=sys.argv[3]
output=open(output_file,'w')
output_comment=sys.argv[4]
output.write('#'+output_comment+'\n')
thresholds=['<0.1','<0.2','<0.3','<0.4','<0.5','<0.6','<0.7','<0.8','<0.9','<1.0','=1.0']
output.write('{:22s}'.format('#Species_status_stage')+' '.join(['{:5s}'.format(x) for x in thresholds])+'\n')

for species in kept_species_list:
    # Discarded edges
    if species in disc_species_list:
        disc_prior_scores=[adj_prior(adj) for adj in disc_adjacencies[species]]
        (disc_prior_hist,bins) = np.histogram(disc_prior_scores,bins=11,range=(0,1.1))
        output.write('{:22s}'.format(species+'_disc_prior')+' '.join(['{:5s}'.format(str(x)) for x in disc_prior_hist])+'\n')
        disc_posterior_scores=[adj_posterior(adj) for adj in disc_adjacencies[species]]
        (disc_posterior_hist,bins) = np.histogram(disc_posterior_scores,bins=11,range=(0,1.1))
        output.write('{:22s}'.format(species+'_disc_post')+' '.join(['{:5s}'.format(str(x)) for x in disc_posterior_hist])+'\n')
    else:
        output.write('{:22s}'.format(species+'_disc_prior')+' '.join(['{:5s}'.format(str(x)) for x in [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]])+'\n')
        output.write('{:22s}'.format(species+'_disc_post')+' '.join(['{:5s}'.format(str(x)) for x in [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]])+'\n')

    # Kept edges
    kept_prior_scores=[adj_prior(adj) for adj in kept_adjacencies[species]]
    (kept_prior_hist,bins) = np.histogram(kept_prior_scores,bins=11,range=(0,1.1))
    output.write('{:22s}'.format(species+'_kept_prior')+' '.join(['{:5s}'.format(str(x)) for x in kept_prior_hist])+'\n')
    kept_posterior_scores=[adj_posterior(adj) for adj in kept_adjacencies[species]]
    (kept_posterior_hist,bins) = np.histogram(kept_posterior_scores,bins=11,range=(0,1.1))
    output.write('{:22s}'.format(species+'_kept_post')+' '.join(['{:5s}'.format(str(x)) for x in kept_posterior_hist])+'\n')
