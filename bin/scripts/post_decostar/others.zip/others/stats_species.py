__author__="Cedric Chauve"
__email__="cedric.chauve@sfu.ca"
__date__="September 26, 2016"

import sys
import numpy as np
import os.path

# This script takes in entry 
# - a file of genomes
# - a directory where to access results files
# - a threshold of conserved adjacencies
# - an output file name
# Then it considers the 5 following sets of scaffolds:
# - observed (F1_obs), F1, F2, M1, M2
# and for each provides the following statistics:
# number of fragments, mean size, standard deviation, N50, N70, N90, three largest fragments

# --------------------------------------------------------------------------------------------

# Reading genomes id and names
GENOMES=[]
GENOMES_STREAM=open(sys.argv[1],"r").readlines()
for g in GENOMES_STREAM:
    g1=g.rstrip().split()
    GENOMES.append((g1[0],g1[1]))

# Reading the data directory and threshold of conserved adjacencies   
DATA_DIR=sys.argv[2]
THRESHOLD=sys.argv[3]
EXPERIMENTS=['F1_obs','F1','F2','M1','M2']
NB_GENES=0

# Reading a scaffolds file (exp in [F1_obs,F1,F2,M1,M2])
def read_scaffolds(gid,gname,exp):
    scfs_stream=open(DATA_DIR+"/species_"+gid+"_"+THRESHOLD+"_"+exp+"_scaffolds","r").readlines()
    SCFS_SIZE_AUX={}
    current_scf=0
    size_index=0
    for l in scfs_stream:
        if l[0]!="#":
            l1=l.rstrip().split()
            if int(l1[0])!=current_scf:
                size_index+=1
                current_scf=int(l1[0])
                SCFS_SIZE_AUX[size_index]=1
            else:
                SCFS_SIZE_AUX[size_index]+=1
    SCFS_SIZE=[]
    for i in SCFS_SIZE_AUX.keys():
        SCFS_SIZE.append(SCFS_SIZE_AUX[i])
    SCFS_SIZE.sort(reverse=True)
    return(SCFS_SIZE)
    
# Computing NXX
def compute_NXX(scfs_size, xx):
    target=NB_GENES*xx/100
    i=0
    nbg=0
    while nbg<target:
        nbg+=scfs_size[i]
        i+=1
    return(i)

# Computing the required statistics
# number of fragments, mean size, standard deviation, N50, N70, N90, three largest fragments
def compute_stats(scfs_size):
    nb_frags=str(len(scfs_size))
    mean=str(format(np.mean(scfs_size),'.2f'))
    std=str(format(np.std(scfs_size),'.2f'))
    N50=str(compute_NXX(scfs_size,50))
    N70=str(compute_NXX(scfs_size,70))
    N90=str(compute_NXX(scfs_size,90))
    frag1=str(scfs_size[0])
    frag2=str(scfs_size[1])
    frag3=str(scfs_size[2])
    return((nb_frags,mean,std,N50,N70,N90,frag1,frag2,frag3))

# Main function
REWRITE={'F1_obs':'obs', 'F1':'F1', 'F2':'F2', 'M1':'M1', 'M2':'M2'}
OUTPUT_FILE=open(sys.argv[4],"w")
OUTPUT_FILE.write("# Data sets description:\n")
OUTPUT_FILE.write("#   obs = initial(observed) scaffolds\n")
OUTPUT_FILE.write("#   F1  = stringent filtering, allowing to discard observed adjacencies\n")
OUTPUT_FILE.write("#   F2  = stringent filtering, forcing to keep observed adjacencies\n")
OUTPUT_FILE.write("#   M1  = MWM filtering, allowing to discard observed adjacencies\n")
OUTPUT_FILE.write("#   M2  = MWM filtering, forcing to keep observed adjacencies\n")
OUTPUT_FILE.write("# Displayed statistics:\n")
OUTPUT_FILE.write("#   species_id species_name nb_genes\n")
OUTPUT_FILE.write("#   algorithm\tnb_scaffolds mean_#genes sandard_dev_#genes --\tN50 N70 N90 --\tthree_largest_scaffolds\n")

for (gid,gname) in GENOMES:
    # Comuting gene number
    scfs_size=read_scaffolds(gid,gname,'F1_obs')
    NB_GENES=0
    for s in scfs_size:
        NB_GENES+=s
    OUTPUT_FILE.write(gid+" "+gname+" "+str(NB_GENES)+"\n")
    # Computing all statistics
    for exp in EXPERIMENTS:
        if os.path.isfile(DATA_DIR+"/species_"+gid+"_"+THRESHOLD+"_"+exp+"_scaffolds"):
            scfs_size=read_scaffolds(gid,gname,exp)
            (s1,s2,s3,s4,s5,s6,s7,s8,s9)=compute_stats(scfs_size)
            OUTPUT_FILE.write("\t"+REWRITE[exp]+"\t"+s1+" "+s2+" "+s3+" --\t"+s4+" "+s5+" "+s6+" --\t"+s7+" "+s8+" "+s9+"\n")
        else:
            OUTPUT_FILE.write("\t"+REWRITE[exp]+"\t"+"NA"+" "+"NA"+" "+"NA"+" --\t"+"NA"+" "+"NA"+" "+"NA"+" --\t"+"NA"+" "+"NA"+" "+"NA"+"\n")
